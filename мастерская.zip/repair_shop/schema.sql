CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('client','master','admin'))
);
CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    price REAL NOT NULL CHECK (price >= 0)
);
CREATE TABLE IF NOT EXISTS parts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    qty INTEGER NOT NULL CHECK (qty >= 0),
    price REAL NOT NULL CHECK (price >= 0)
);
CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES users(id),
    master_id INTEGER REFERENCES users(id),
    device TEXT NOT NULL,
    problem TEXT NOT NULL,
    photo TEXT,
    status TEXT NOT NULL DEFAULT 'принята',
    comment TEXT DEFAULT '',
    work_cost REAL NOT NULL DEFAULT 0 CHECK (work_cost >= 0),
    created TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS request_parts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id INTEGER NOT NULL REFERENCES requests(id),
    part_id INTEGER NOT NULL REFERENCES parts(id),
    qty INTEGER NOT NULL CHECK (qty > 0)
);
