# Ремонтная мастерская (учебный проект)

Flask + SQLite + HTML/CSS/JS.

## Запуск
    нужно в самой папке открыть консоль cmd и не закрывать её пока пользуетесь сайтом
    pip install -r requirements.txt
    python app.py
Открыть http://127.0.0.1:5000.

## Тестовые пользователи
- Админ: admin@mail.ru / admin123
- Мастер: master@mail.ru / master123
- Клиент: client@mail.ru / client123

## Файлы
- app.py - весь backend (маршруты, роли, работа с БД)
- schema.sql - структура базы данных
- templates/ - страницы, static/style.css - стили
- test_app.py - простой автотест (python test_app.py)
