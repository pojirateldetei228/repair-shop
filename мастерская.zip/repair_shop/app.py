import os, sqlite3, time
from functools import wraps
from flask import Flask, render_template, request, redirect, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'study-secret-key'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # фото не больше 5 МБ
DB = 'shop.db'
UPLOADS = os.path.join('static', 'uploads')
STATUSES = ['принята', 'в диагностике', 'в ремонте', 'готова к выдаче', 'выдана']
DEVICES = ['Телефон', 'Ноутбук', 'Планшет', 'Компьютер', 'Другое']


def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(e):
    d = g.pop('db', None)
    if d:
        d.close()


def q(sql, args=(), one=False):
    # все запросы с параметрами (?) - так нет SQL-инъекций
    rows = db().execute(sql, args).fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def ex(sql, args=()):
    cur = db().execute(sql, args)
    db().commit()
    return cur.lastrowid


def need(role=None):
    def deco(f):
        @wraps(f)
        def wrap(*a, **k):
            if 'uid' not in session:
                return redirect('/login')
            if role and session['role'] != role:
                return 'Доступ запрещён', 403
            return f(*a, **k)
        return wrap
    return deco


def number(text, minimum=0):
    n = float(text)
    if n < minimum:
        raise ValueError
    return n


def init_db():
    con = sqlite3.connect(DB)
    con.executescript(open('schema.sql', encoding='utf-8').read())
    if not con.execute('select count(*) from users').fetchone()[0]:
        for name, email, pw, role in [('Админ', 'admin@mail.ru', 'admin123', 'admin'),
                                      ('Иван Мастер', 'master@mail.ru', 'master123', 'master'),
                                      ('Петр Клиент', 'client@mail.ru', 'client123', 'client')]:
            con.execute('insert into users(name,email,password_hash,role) values(?,?,?,?)',
                        (name, email, generate_password_hash(pw), role))
        con.executemany('insert into services(title,price) values(?,?)',
                        [('Замена экрана телефона', 3000), ('Замена аккумулятора', 1500),
                         ('Чистка ноутбука от пыли', 1000), ('Установка Windows', 800),
                         ('Диагностика', 0)])
        con.executemany('insert into parts(name,qty,price) values(?,?,?)',
                        [('Экран для телефона', 5, 2000), ('Аккумулятор', 8, 700),
                         ('Термопаста', 20, 100), ('SSD 256 ГБ', 3, 2500)])
        con.executemany('insert into requests(client_id,master_id,device,problem,status,work_cost,created) values(3,?,?,?,?,?,?)',
                        [(2, 'Телефон', 'Разбит экран после падения', 'в ремонте', 0, '2026-11-02 10:00'),
                         (2, 'Ноутбук', 'Сильно шумит и греется', 'выдана', 1000, '2026-11-05 12:00'),
                         (None, 'Планшет', 'Не заряжается от кабеля', 'принята', 0, '2026-11-10 09:30')])
        con.commit()
    con.close()
    os.makedirs(UPLOADS, exist_ok=True)


@app.route('/')
def index():
    return render_template('catalog.html', services=q('select * from services order by title'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip().lower()
        pw = request.form['password']
        if len(name) < 2 or '@' not in email or len(pw) < 6:
            flash('Имя от 2 символов, e-mail с @, пароль от 6 символов')
        elif q('select id from users where email=?', (email,), one=True):
            flash('Такой e-mail уже зарегистрирован')
        else:
            ex('insert into users(name,email,password_hash,role) values(?,?,?,?)',
               (name, email, generate_password_hash(pw), 'client'))
            flash('Регистрация прошла, теперь войдите')
            return redirect('/login')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = q('select * from users where email=?', (request.form['email'].strip().lower(),), one=True)
        if u and check_password_hash(u['password_hash'], request.form['password']):
            session['uid'], session['role'], session['name'] = u['id'], u['role'], u['name']
            return redirect({'client': '/my', 'master': '/master', 'admin': '/admin'}[u['role']])
        flash('Неверный e-mail или пароль')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


@app.route('/new', methods=['GET', 'POST'])
@need('client')
def new():
    if request.method == 'POST':
        device = request.form['device']
        problem = request.form['problem'].strip()
        f = request.files.get('photo')
        ext = f.filename.rsplit('.', 1)[-1].lower() if f and f.filename else ''
        if device not in DEVICES or not 10 <= len(problem) <= 500:
            flash('Описание неисправности должно быть от 10 до 500 символов')
        elif f and f.filename and ext not in ('jpg', 'jpeg', 'png'):
            flash('Фото должно быть jpg или png')
        else:
            photo = ''
            if ext:
                photo = '%d_%d.%s' % (session['uid'], time.time(), ext)
                f.save(os.path.join(UPLOADS, photo))
            ex('insert into requests(client_id,device,problem,photo) values(?,?,?,?)',
               (session['uid'], device, problem, photo))
            flash('Заявка создана')
            return redirect('/my')
    return render_template('new.html', devices=DEVICES)


@app.route('/my')
@need('client')
def my():
    rows = q('select * from requests where client_id=? order by id desc', (session['uid'],))
    return render_template('my.html', rows=rows, statuses=STATUSES)


@app.route('/master')
@need('master')
def master():
    rows = q('select * from requests where master_id=? order by id desc', (session['uid'],))
    used = {r['id']: q('select p.name, rp.qty from request_parts rp join parts p on p.id=rp.part_id '
                       'where rp.request_id=?', (r['id'],)) for r in rows}
    return render_template('master.html', rows=rows, used=used, statuses=STATUSES,
                           parts=q('select * from parts where qty>0'))


@app.route('/master/<int:rid>', methods=['POST'])
@need('master')
def master_update(rid):
    if not q('select id from requests where id=? and master_id=?', (rid, session['uid']), one=True):
        return 'Это не ваша заявка', 403
    f = request.form
    try:
        if f['status'] not in STATUSES:
            raise ValueError
        cost = number(f.get('work_cost') or 0)
        ex('update requests set status=?, comment=?, work_cost=? where id=?',
           (f['status'], f['comment'].strip()[:300], cost, rid))
        if f.get('part_id') and f.get('part_qty'):
            n = int(number(f['part_qty'], 1))
            part = q('select * from parts where id=?', (f['part_id'],), one=True)
            if part and n <= part['qty']:
                ex('insert into request_parts(request_id,part_id,qty) values(?,?,?)', (rid, part['id'], n))
                ex('update parts set qty=qty-? where id=?', (n, part['id']))
            else:
                flash('На складе нет столько запчастей')
    except (ValueError, KeyError):
        flash('Проверьте введённые данные')
    return redirect('/master')


@app.route('/admin')
@need('admin')
def admin():
    reqs = q('select r.*, u.name client, m.name master from requests r join users u on u.id=r.client_id '
             'left join users m on m.id=r.master_id order by r.id desc')
    return render_template('admin.html', reqs=reqs, services=q('select * from services'),
                           parts=q('select * from parts'), users=q('select * from users'),
                           masters=q("select * from users where role='master'"))


@app.route('/admin/<action>', methods=['POST'])
@need('admin')
def admin_action(action):
    f = request.form
    try:
        if action == 'assign':
            ex('update requests set master_id=? where id=?', (f['master_id'] or None, f['rid']))
        elif action == 'service':
            ex('insert into services(title,price) values(?,?)', (f['title'].strip(), number(f['price'])))
        elif action == 'del_service':
            ex('delete from services where id=?', (f['id'],))
        elif action == 'part':
            ex('insert into parts(name,qty,price) values(?,?,?)',
               (f['name'].strip(), int(number(f['qty'])), number(f['price'])))
        elif action == 'restock':
            ex('update parts set qty=qty+? where id=?', (int(number(f['qty'], 1)), f['id']))
        elif action == 'user':
            if len(f['password']) < 6 or f['role'] not in ('master', 'admin'):
                raise ValueError
            ex('insert into users(name,email,password_hash,role) values(?,?,?,?)',
               (f['name'].strip(), f['email'].strip().lower(), generate_password_hash(f['password']), f['role']))
    except (ValueError, KeyError, sqlite3.IntegrityError):
        flash('Ошибка в данных (пустое поле, дубликат или отрицательное число)')
    return redirect('/admin')


@app.route('/stats')
@need('admin')
def stats():
    one = lambda sql: q(sql, one=True)[0]
    income = one("select coalesce(sum(work_cost),0) from requests where status='выдана'") + \
        one("select coalesce(sum(rp.qty*p.price),0) from request_parts rp join parts p on p.id=rp.part_id "
            "join requests r on r.id=rp.request_id where r.status='выдана'")
    data = {
        'status': [list(r) for r in q('select status, count(*) from requests group by status')],
        'days': [list(r) for r in q('select date(created), count(*) from requests group by 1 order by 1')],
        'devices': [list(r) for r in q('select device, count(*) from requests group by 1')],
        'load': [list(r) for r in q("select u.name, count(r.id) from users u left join requests r "
                                    "on r.master_id=u.id and r.status!='выдана' where u.role='master' group by u.id")],
    }
    return render_template('stats.html', data=data, income=income)


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
